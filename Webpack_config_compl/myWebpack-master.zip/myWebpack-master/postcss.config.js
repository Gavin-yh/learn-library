module.exports = {       //对厂商前缀 插件的配置，不提倡这种繁琐的写法。直接在options中配置即可
    plugins:[
        require('autoprefixer')
    ]
  }